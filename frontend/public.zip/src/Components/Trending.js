import React from 'react'
import webdesigning from "../img/T1-Web.png"
import tshirtdesigning from "../img/T2-Tshirt.png"
import brandidentity from "../img/T3-Brand.png"
import packagingdesigning from "../img/T4-Packaging.png"
// import bookcovering from "../img/T5-BookCover.png"
import './Home.css';

const Trending = () => {
  return (
    <div className='TrendingSection'>
			<div class="trending-title">
				<h3>Our design <strong>services</strong></h3>
			</div>
		  <div class="">
			  <div class="">
		      <div class="">
			      <div class="">
						  <img src={tshirtdesigning} class="" alt="" />
					    <p class="">Logo Design</p>
			      </div>
		      </div>
		    </div>
			  <div class="">
		      <div class="">
			      <div class="">
						  <img src={brandidentity} class="" alt="" />
					    <p class="">Brand Identity</p>
			      </div>
		      </div>
		    </div>
			  <div class="">
		      <div class="">
			      <div class="">
						  <img src={webdesigning} class="" alt="" />
					    <p class="">Web Design</p>
			      </div>
		      </div>
			  </div>
		    <div class="">
		      <div class="">
					  <div class="">
				      <img src={packagingdesigning} class="" alt="" />
				      <p class="">Packaging Design</p>
			      </div>
          </div>
        </div>
      </div>
      {/* <div className='headingtrending'>
        <h1>Trending</h1>
      </div>
      <div className='Web_designs'>
        <div> 
          <img src={webdesigning} alt="" />
          <h4><br />Web Design</h4>
        </div>      
        <div className='tshirt_design'>
          <div>
            <img src={tshirtdesigning} alt="" />
            <h4><br />T-shirts Design</h4>
          </div>
        </div>
        <div className='brand_identity'>
          <div> 
            <img src={brandidentity} alt="" />
            <h4><br />Brand identity</h4>
          </div>
        </div>
        <div className='packaging_design'>
          <div>
            <img src={packagingdesigning} alt="" />
            <h4><br />Packaging Design</h4>
          </div>
        </div>
        <div className='book_cover_design'>
          <div> 
            <img src={bookcovering} alt="" />
            <h4><br />Book cover Design</h4>
          </div>
        </div>
      </div> */}
    </div>
  );
}

export default Trending;