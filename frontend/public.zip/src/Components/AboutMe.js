import React, { useEffect, useState } from "react";
import AboutMee from "../img/AboutMe.png";
import "./styles/AboutMe.css";
import axios from "axios";

const ContestTitle = (props) => {
  const [data, setData] = useState([]);
  const getdata = () => {
    fetch(`/browse/contestopen/${props.id}`)
      .then((response) => response.json())
      .then((data) => setData(data));
  };
  useEffect(() => {
    getdata();
  }, [props]);
  return (
    <div>
      <h2>Contest Title : {data.contesttitle}</h2>
      <h2>Contest Type : {data.designtype}</h2>
    </div>
  );
};

const AboutMe = () => {
  const [data, setData] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));
  const getwinner = () => {
    axios
      .get(`/winner/${user.id}`)
      .then((res) => setData(res.data))
      .catch((err) => console.log(err, "it has an error"));
  };

  useEffect(() => {
    getwinner();
  }, []);
  return (
    <div>
      <div className="AboutMe-Page">
        <div className="AM-container">
          <div className="AM-left" style={{ padding: "20px" }}>
            <div className="AM-title">
              <h3 style={{ display: "flex", justifyContent: "center" }}>
                PROFILE
              </h3>
            </div>
            <div className="AM-name">
              <h5>NAME</h5>
              <p>{user.name}</p>
            </div>
            <div className="AM-email">
              <h5>EMAIL</h5>
              <p>{user.email}</p>
            </div>
            <div className="AM-role">
              <h5>ROLE</h5>
              <p>{user.type}</p>
            </div>
          </div>
          <div className="AM-right">
            <img className="AM-image" src={AboutMee} alt="" />
          </div>
        </div>
      </div>
      <h3 style={{ display: "flex", justifyContent: "center" }}>
        Contests Win by {user.name}
      </h3>
      <div style={{ backgroundColor: "white", padding: "25px" }}>
        {data.map((item) => (
          <div style={{ padding: "25px" }}>
            <ContestTitle id={item.contestId} />
            <h4>Winner Name : {item.name}</h4>
            <h4>Email : {item.email}</h4>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AboutMe;
