import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";

const user = JSON.parse(localStorage.getItem("user"));

function ImagesView(props) {
  const location = useLocation();
  let data = props.data;
  useEffect(() => {
    console.log(data);
  }, [data]);

  function arrayBufferToBase64(buffer) {
    var binary = "";
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
  const selectedWinner = (id) => {
    fetch("/winner", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: user.name,
        email: user.email,
        contestId: location.state.id,
        userId: id,
      }),
    });
    console.log("winner id ", id);
  };
  return (
    <div>
      <h2>Images for this contest</h2>
      <div style={{ display: "flex", flexWrap: "wrap", width: "100%" }}>
        {data.map((item) => {
          let base64String = arrayBufferToBase64(item.img.data.data);
          return (
            <div style={{ padding: "30px" }}>
              <div
                style={{
                  padding: "30px 20px",
                  borderRadius: "10px",
                  boxShadow: "3px 2px 14px 1px grey",
                  background: "white",
                }}
              >
                <img
                  src={`data:image/png;base64,${base64String}`}
                  width="200"
                  height="200"
                  alt=""
                />
                <span style={{ display: "flex" }}>
                  <h4>Name : </h4>
                  <h4> {item.name}</h4>
                </span>
                <span style={{ display: "flex" }}>
                  <p>email : </p>
                  <p> {item.email}</p>
                </span>

                <button
                  style={{
                    padding: "5px",
                    border: "2px solid black",
                    display: "flex",

                    margin: "auto",
                  }}
                  onClick={() => selectedWinner(item.userId)}
                >
                  Selected
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default ImagesView;
