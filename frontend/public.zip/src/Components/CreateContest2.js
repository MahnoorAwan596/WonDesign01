import React, {useState} from "react";
// import hours from "../img/48hours.png";
// import week1 from "../img/1week.png";
// import week2 from "../img/2week.png";
// import month from "../img/month.png";
// import selectDate from "../img/selectDate.png";
// import ques from "../img/questionMark.png";
// import create from "../img/create.png";
import { useNavigate } from 'react-router-dom';
// import { sendRequest } from "../api/sendRequest";
import FooterNew from "./FooterNew";

const CreateContest2 = () => {


    const [contest, setContest] = useState({
        contesttitle: "", designtype:"", description:"", 
        designusedas:"", startdate:"", enddate:"", 
        budget:"", additionaldescription:""
    });

    // const [allEntry, setAllEntry] = useState([]);

    let name, value;

    const handleCreateInputs = (e) => {
        console.log(e);
        name = e.target.name;
        value = e.target.value;

        setContest({ ...contest, [name]:value});
    }

    const navigate = useNavigate();

    const PostContest = async (e) => {
        e.preventDefault();

        const { contesttitle, designtype, description, 
            designusedas, startdate, enddate, 
            budget, additionaldescription } = contest;

        const res = await fetch("/browse", {
            method: "POST",
            headers: {
                "Content-Type" : "application/json"
            },
            body: JSON.stringify({ contesttitle, designtype, description, 
                designusedas, startdate, enddate, 
                budget, additionaldescription})
        })

        const data = await res.json();

        if (res.status === 422 || !data) {
            window.alert("Invalid Credentials");
            console.log("Invalid Credentials");
        } else {
            window.alert("Contest created successfully");
            console.log("Contest created successfully");

            navigate('/browse');

            // const newEntry = { contesttitle: contesttitle, designtype: designtype,
            //     description: description, designusedas: designusedas, startdate: startdate, 
            //     enddate: enddate, budget: budget, additionaldescription: additionaldescription }
    
            // setAllEntry([ ...allEntry, newEntry ]);

            // sendRequest()
            //     .then(setResponse)
            //     .then(() => {
            //         navigate('/c/browse');
            // })
        }
    }

    const Back = () => {
        navigate('/create');
    }

    return (
        <div className="c-c-2">
            <div className="dataCollection">
                <div className="dataCollectionTitle">
                    <h1>Tell us about your contest</h1>
                </div>
                <button className='backButton' onClick={Back}>Back</button>
                <form method="POST" className="dataCollectionForm">
                    <div className="field1">
                        <label className="label"><h3><b>Name your contest</b></h3></label>
                        <input type="text" className="inputField1" placeholder="E.g. Packaging for an organic juice company" 
                            name="contesttitle" onChange={handleCreateInputs} value={contest.contesttitle} autoComplete="off"  />
                    </div>
                    <div className="field1">
                        <label className="label"><h3><b>What type of design do you need?</b></h3></label>
                        <select className="inputField1" name="designtype" onChange={handleCreateInputs} value={contest.designtype} autoComplete="off">
                            <option value disabled>Select category</option>
                            <option>Logo & identity</option>
                            <option>Web & app design</option>
                            <option>Business & advertising</option>
                            <option>Clothing & merchandise</option>
                            <option>Art & illustration</option>
                            <option>Packaging & label</option>
                            <option>Book & magazine</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div className="field2">
                        <label className="label"><h3><b>Description</b></h3></label>
                        <textarea className="inputField2" placeholder="E.g. I need a package designed for a new flavor of organic juice. It should feature a retro and vibrant design style and include our company logo on the front of the bottle. Our juice appeals to adults aged from 25-35.  Our bottle contains 500mls (see attached reference image for actual shape and size)." 
                            name="description" onChange={handleCreateInputs} value={contest.description} autoComplete="off" />
                    </div>
                    <div className="field1">
                        <label className="label"><h3><b>How will your design be used?</b></h3></label>
                        <input type="text" className="inputField1" placeholder="E.g. Billboard, Facebook campaign, bookcover etc." 
                            name="designusedas" onChange={handleCreateInputs} value={contest.designusedas} autoComplete="off" />
                    </div>
                    {/* <div className="field2">
                        <label className="label"><h3><b>Add reference files</b></h3></label>
                        <p>Upload any files you have to help your designer create your logo which may include an existing logo, photos, your brand guide, fonts, copy, or any other informative documents.</p>
                        <input type="file" className="inputField5" name="referencefiles" 
                            onChange={handleCreateInputs} autoComplete="off" />
                    </div> */}
                    {/* <div className="field3">
                        <label className="label"><h3><b>What's your timeline?</b></h3></label>
                        <p>Your designer will confirm whether your delivery date can be met based on project scope and their availability.</p>
                        <div className="timeButtonsRow1">
                            <button className="buttonField1" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={hours} alt="" />
                                <h6><b>48 hours</b></h6>
                            </button>
                            <button className="buttonField2" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={week1} alt="" />
                                <h6><b>1 week</b></h6>
                            </button>
                            <button className="buttonField2" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={week2} alt="" />
                                <h6><b>2 weeks</b></h6>        
                            </button>
                        </div>
                        <div className="timeButtonsRow2">
                            <button className="buttonField1" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={month} alt="" />
                                <h6><b>1 month</b></h6>
                            </button>
                            <button className="buttonField2" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={selectDate} alt="" />
                                <h6><b>Choose start & end date</b></h6>
                            </button>
                            <button className="buttonField2" type="radio" data-selected="false" >
                                <img className="buttonImage1" src={ques} alt="" />
                                <h6><b>I'd like to chat</b></h6>     
                            </button>
                        </div>
                    </div> */}
                    <div className="field1">
                        <label className="label"><h3><b>Start date</b></h3></label>
                        <input type="date" className="inputField1" name="startdate" 
                            onChange={handleCreateInputs} value={contest.startdate} autoComplete="off" />
                    </div>
                    <div className="field1">
                        <label className="label"><h3><b>End date</b></h3></label>
                        <input type="date" className="inputField1" name="enddate" onChange={handleCreateInputs} 
                            value={contest.enddate} autoComplete="off" />
                    </div>
                    <div className="field4">
                        <label className="label"><h3><b>What's your budget?</b></h3></label>
                        <p>Your designer will use your budget and brief details to provide a quote</p>
                        <div className="amountInput">
                            <div className="dollarSign">$</div>
                            <input type="number" className="inputField4" placeholder="Enter amount" 
                                name="budget" onChange={handleCreateInputs} value={contest.budget} autoComplete="off" />
                        </div>
                        <div className="priceGuide">
                            <p>Price guide: $50 - $1000</p>
                            <hr></hr>
                            <p>*WonDesign adds a 5% platform fee to cover support and processing payment</p>
                        </div>
                    </div>
                    {/* <div className="field1">
                        <label className="label"><h3><b>What industry are you in?</b></h3></label>
                        <select className="inputField1" name="industry" 
                            onChange={handleCreateInputs} value={contest.industry} 
                            autoComplete="off">
                            <option value disabled>Select industry</option>
                            <option>Accounting & financial</option>
                            <option>Agriculture</option>
                            <option>Art & design</option>
                            <option>Business & consulting</option>
                            <option>Childcare</option>
                            <option>Communications</option>
                            <option>Construction</option>
                            <option>Education</option>
                            <option>Fashion</option>
                            <option>Food & drink</option>
                            <option>Games</option>
                            <option>Landscaping</option>
                            <option>Medical</option>
                            <option>Photography</option>
                            <option>Restaurant</option>
                            <option>Security</option>
                            <option>Sports</option>
                            <option>Travel & hotel</option>
                            <option>Wedding service</option>
                            <option>Other</option>
                        </select>
                    </div> */}
                    {/* <div className="field1">
                        <label className="label"><h3><b>Add your website and/or social media pages</b></h3></label>
                        <input type="text" className="inputField1" placeholder="E.g. www.best-site-ever.com" 
                            name="socialmediapages" onChange={handleCreateInputs} autoComplete="off" />
                    </div> */}
                    <div className="field2">
                        <label className="label"><h3><b>Anything else you'd like to share?</b></h3></label>
                        <textarea className="inputField2" name="additionaldescription" onChange={handleCreateInputs} 
                            value={contest.additionaldescription} autoComplete="off" />
                    </div>
                    <div className="NextButtonDiv">
                        <button onClick={PostContest} type="submit" className="next2-button" name="">Create Contest</button>
                    </div>
                </form>
            </div>
            
            {/* <div>
                {
                    allEntry.map((curElem) => {
                        return (
                            <div>
                                <p>{curElem.contesttitle}</p>
                                <p>{curElem.designtype}</p>
                                <p>{curElem.description}</p>
                                <p>{curElem.designusedas}</p>
                                <p>{curElem.startdate}</p>
                                <p>{curElem.enddate}</p>
                                <p>{curElem.budget}</p>
                                <p>{curElem.additionaldescription}</p>
                            </div>
                        )
                    })
                }
            </div> */}
            <FooterNew />
        </div>
    );
}
export default CreateContest2;