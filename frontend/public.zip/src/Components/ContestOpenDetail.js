import React, { useEffect, useState } from 'react'
import ContestOpen from './ContestOpen'

const ContestOpenDetail = () => {
  const [contests, setContests] = useState(null)

  useEffect(() => {
    const fetchContests = async () => {
      const response = await fetch('/browse')
      const json = await response.json()

      if (response.ok) {
        setContests(json)
      }
    }
    fetchContests()
  }, [])

  return (
    <div>
      {contests && contests.map((contest) => (
        <ContestOpen key={contest._id} contest={contest} />
      ))}
    </div>
  )
}

export default ContestOpenDetail