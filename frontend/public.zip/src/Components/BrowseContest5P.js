import React from 'react'
import { useNavigate } from 'react-router-dom';

const BrowseContest5P = () => {

  const navigate = useNavigate();

    const CallWeb = () => {
        navigate('/browse');
    }
    const CallMobile = () => {
        navigate('/browse2');
    }
    const CallLogo = () => {
        navigate('/browse3');
    }
    const CallDigital = () => {
        navigate('/browse4');
    }
    const CallPrint = () => {
        navigate('/browse5');
    }

  return (
    <div className="browse-page">
            <div className="contest-page-title">
                <br></br>
                <h3>Welcome to <span>Contest's World!</span></h3>
            </div>
            <div className="buttons-group">
                <button type="button" onClick={CallWeb} className="but buttonb-1">Web Design</button>
                <button type="button" onClick={CallMobile} className="but buttonb-2">Mobile App Design</button>
                <button type="button" onClick={CallLogo} className="but buttonb-3">Logo Design</button>
                <button type="button" onClick={CallDigital} className="but buttonb-4">Digital Design</button>
                <button type="button" onClick={CallPrint} className="but buttonb-5" style={{backgroundColor: "#0d9bb9"}}>Print Design</button>
            </div>
        </div>
  )
}

export default BrowseContest5P