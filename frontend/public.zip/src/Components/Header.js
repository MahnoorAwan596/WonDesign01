import React from 'react'
import bg from "../img/HeaderGroup.svg"
import './Home.css'
  
const Header = () => {
  return (
    <div className='banner'>
      <div className='banner-text'>
        <h1 className='customizable'>
          <span className='roboto-normal-black-60px'>Customizable </span>
          <span className='span1'>
            Design.
          </span>
          <span className='roboto-normal-black-60px'>
            <br />
            At your service.
          </span>
        </h1>
        <div className='para'>
            <p>
              We make it easy to work with professional designers, creative experts from
              Australia to build your brand through custom, memorable design which have
              lasting impact on your business.
            </p>
        </div>
      </div>
      <div className='banner-image'>
          <img src={bg} alt="" className='img'/>
      </div>   
    </div>    
  );
}

export default Header;