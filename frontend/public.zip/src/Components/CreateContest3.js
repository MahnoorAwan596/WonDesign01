import React from 'react'
import { useNavigate } from 'react-router-dom';

const CreateContest3 = () => {

  const navigate = useNavigate();

  const Back = () => {
    navigate('/createtwo');
  }

  return (
    
    <div>
      <div className="dataCollection">
        <div className="dataCollectionTitle">
          <h1>Review your brief</h1>
        </div>
        <button className='backButton' onClick={Back}>Back</button>
        <form className="dataCollectionForm">
          <div className="field11">
            <label className="title11"><h2><b>Tell us about your business</b></h2></label>
            <div className='part11'>
              <h5>Name your project</h5>
              <p>data</p>
              <hr></hr>
            </div>
            <div className='part11'>
              <h5>What type of design do you need?</h5>
              <p>designtype</p>
              <hr></hr>
            </div>
            <div className='part11'>
              <h5>Describe your project</h5>
              <p>description</p>
              <hr></hr>
            </div>
            <div className='part11'>
              <h5>How will your design be used?</h5>
              <p>designusedas</p>
            </div>
          </div>
          <div className="field12">
            <label className="title11"><h2><b>Your time & budget</b></h2></label>
            <div className='part11'>
              <h5>What's your timeline?</h5>
              <p>startdate</p>
              <hr></hr>
            </div>
            <div className='part11'>
              <h5>What's your budget?</h5>
              <p>$budget</p>
            </div>
          </div>
          <div className="NextButtonDiv">
            <button onClick="" type="submit" className="lets-do-this-button" name="">Let's do this!</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreateContest3