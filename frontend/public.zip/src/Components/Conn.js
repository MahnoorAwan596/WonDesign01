const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const form = express();

form.use(express.json());
form.use(cors());

const database = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Qw@1212qw",
    database: "wondesign",
});

form.post("/signup", (req, res) => {

    const email = req.body.email;
    const password = req.body.password;

    database.query(
      "INSERT INTO users (email, password) VALUES (?,?)",
      [email, password],
      (err, result) => {
        console.log(err);
    }
    );
});

form.listen(3002, () => {
    console.log("Connection successful...");
});