import React from 'react'
import './Home.css';
import one from "../img/One.png";
import frame1 from "../img/Frame-1.png";
import two from "../img/Two.png";
import frame2 from "../img/Frame-2.png";
import three from "../img/Three.png";

const Design = () => {
    return (
        <div className='designSection'>
            <div className='title'>
                <h1>Our Design Process</h1>
            </div>
            <div className='figure'>
                <div className='one'>
                    <img className='' src={one} alt=''/>
                </div>
                <div className='frame-1'>
                    <img className='' src={frame1} alt=''/>
                </div>
                <div className='two'>
                    <img className='' src={two} alt=''/>
                </div>
                <div className='frame-2'>
                    <img className='' src={frame2} alt=''/>
                </div>
                <div className='three'>
                    <img className='' src={three} alt=''/>
                </div>
            </div>
            <div className='fig-text'>
                <div className='fig1'>
                    <div className='fig1-title'>
                        Brief
                    </div>
                    <div className='fig1-text'>
                        Tell us what you need to get designed
                    </div>
                </div>
                <div className='fig2'>
                    <div className='fig2-title'>
                        Start Contest
                    </div>
                    <div className='fig2-text'>
                        Share your brief with designers, they submit their designs, then you pick your favourite one                        
                    </div>
                </div>
                <div className='fig3'>
                    <div className='fig3-title'>
                        Collaborate
                    </div>
                    <div className='fig3-text'>
                        Finalize your design and continue working together                        
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Design;