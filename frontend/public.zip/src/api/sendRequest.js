export const sendRequest = () => {
    return Promise.resolve({
      name: 'bob',
      age: '42',
    });
  };