// const Contest = require("../model/contestSchema")
const mongoose = require("mongoose")

module.exports.addcontestImages = async (req, res) => {
    console.log(req.body, 5)
    try {

    } catch (err) {
        console.log(err)
    }
}