const jwt = require('jsonwebtoken');
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const authenticate = require("../middleware/authenticate");


//database connection 
require("../db/conn.js");
//importing userschema
const User = require("../model/userSchema");
const Contest = require("../model/contestSchema");
const Contact = require("../model/contactSchema");


router.get("/", (req, res) => {
    res.send("Hello HOME from the server router.js");
})

// USING ASYNC AWAIT
// to get data from user we have to use post
router.post("/register", async (req, res) => {
    try {
        const { username, email, password, usertype } = req.body;
        //validation of fields
        if( !username || !email || !password || !usertype ) {
            return res.status(422).json({ error: "Required" })
        } else {
            //check if user exist
            const userExist = await User.findOne({ email: email });
            if (userExist) {
                return res.status(422).json({ error: "Email already exist" });
            } else {
                // getting data & if user does not exist create new
                const user = new User({ username, email, password, usertype });
                // hashing password pre-saving method
                // working in userSchema as a middleware
                // wait to save
                await user.save();
                // registration
                res.json({ message: "user registered successfully" });
            }
        }
    } catch (err) {
        console.log(err);
    }
});

//LOGIN ROUTE
// getting data from login form
router.post("/signin", async (req, res) => {
    // console.log(req.body);
    // res.json({ message: "Awesome!" });
    try {
        const { email, password } = req.body;
        if( !email || !password ) {
            return res.status(400).json({ error: "Required" })
        } else {
            //here userLogin is containing complete data from db
            const userLogin = await User.findOne({ email: email });
             
            if (userLogin) {
                const isMatch = await bcrypt.compare(password, userLogin.password);
                const token = await userLogin.generateAuthToken();
                console.log(token);


                res.cookie( "jwtoken", token, {
                    expires: new Date( Date.now() + 25892000000 ), //cookie should be expire after these milli seconds
                    httpOnly: true //kahan add kr skty wo bta dia http, wrna wo srf secure py chly ga, hm ny http py b chlana hy cookie ko
                });
                if (!isMatch) {
                    res.status(400).json({ error: "Invalid Credentials " });
                } else {
                    res.json({ message: "User Signed In Successfully" });
                }
            } else {
                res.status(400).json({ error: "Invalid Credentials "});
            }
        }
    } catch (err) {
        console.log(err);
    }
});


// get user data for contact page and home page
router.get("/getdata", authenticate ,(req, res) => {
    console.log("Hello my Data");
    res.send(req.rootUser);
});


// logout page
router.get("/logout", (req, res) => {
    console.log("Hello my Logout page");
    res.clearCookie('jwtoken', { path: '/' });
    res.status(200).send("User lOgout.");
});

// create cotest page
router.post( '/createtwo', async ( req, res ) => {

    const { contesttitle, designtype, description, designusedas, startdate, enddate, budget, additionaldescription} = req.body;
    if( !contesttitle || !designtype || !description || !designusedas || !startdate || !enddate || !budget || !additionaldescription ) {
        return res.status(422).json({ error: "Plz fill the field properly" });
    }
    try {
        const contest = new Contest({ contesttitle, designtype, description, designusedas, startdate, enddate, budget, additionaldescription })

        const contestCreated = await contest.save();
        if(contestCreated) {
            res.status(201).json({ message: "Contest created successfully" });
        } else {
            res.status(500).json({error:"Failed to create contest" });
        }
    } catch (err) {
        console.log(err);
    }
});


// contact us page
router.post( '/contact', async ( req, res ) => {
    try {
        const { username, email, usertype, message } = req.body;
        if ( !username || !email || !usertype || !message ) {
            return res.status(422).json({ error: "Required" })
        } else {
            const contact = new Contact({ username, email, usertype, message })
            await contact.save();
            res.json({ message: "Message sent successfully" });
        }
    } catch (err) {
        console.log(err);
    }
})
// show this api data on /browseContest Page 
router.get("/getAllContest" , async (req , res) =>{

    console.log("-------------------------------")
    let noOfContest = await Contest.find()
    let newDate = Date.now()
   
    for (var i = 0; i < noOfContest.length; i++) {

        var GivenDate = noOfContest[i].enddate;
        var CurrentDate = new Date();
        GivenDate = new Date(GivenDate);
        if(GivenDate > CurrentDate){
           console.log("const out of date range")
        }
    }
    res.send(noOfContest)

    //     var GivenDate = '2018-02-22';
    // var CurrentDate = new Date();
    // GivenDate = new Date(GivenDate);

    // if(GivenDate > CurrentDate){
    //     alert('Given date is greater than the current date.');
    // }else{
    //     alert('Given date is not greater than the current date.');
    // }
    //     res.send(noOfContest)
})


module.exports = router; 