const mongoose = require('mongoose');

const Schema = mongoose.Schema

const contestSchema = new Schema({
    contesttitle: {
        type: String,
        required: true
    },
    designtype: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    designusedas: {
        type: String,
        required: true
    },
    // noOfResourcesRequired: {
    //     type: String,
    //     required: true,
    //     max:5
    // },
    // referencefiles: [
    //     {
    //         referencefile: {
    //             type: String,
    //             required: true
    //         }
    //     }
    // ],
    startdate: {
        type: Date,
        required: true
    },
    enddate: {
        type: Date,
        required: true
    },
    budget: {
        type: Number,
        required: true
    },
    // industry: {
    //     type: String,
    //     required: true
    // },
    // socialmediapages: [
    //     {
    //         socialmediapage: {
    //             type: String,
    //             required: true
    //         }
    //     }
    // ],
    additionaldescription: {
        type: String,
        required: true
    }
}, { timestamps: true }) // Timestamps to indicate when the document is created

module.exports = mongoose.model('Contest', contestSchema)