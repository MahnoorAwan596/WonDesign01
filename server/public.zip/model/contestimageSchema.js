const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const contestimageSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  photo: {
    type: String,
    required: true,
  },
});

const Contestimage = mongoose.model("CONTESTIMAGE", contestimageSchema);

module.exports = Contestimage;
